package com.benitha.NE.enums;

public enum TransactionType {
    SAVING,
    WITHDRAW,

    TRANSFER
}
