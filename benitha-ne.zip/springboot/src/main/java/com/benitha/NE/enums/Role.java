package com.benitha.NE.enums;

public enum Role {
    USER
}
